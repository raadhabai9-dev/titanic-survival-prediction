# Titanic Survival Prediction

Frontend-only ML app. React + Vite + Tailwind + TensorFlow.js (Logistic Regression) + a from-scratch
Decision Tree + Recharts + PapaParse + jsPDF + html2canvas. No backend, no external APIs. Data loading,
cleaning, feature engineering, training, evaluation, prediction, and PDF report all run in the browser.

## Run it

npm install
npm run dev

Open the printed local URL. First load: dataset loads, records are cleaned, features are engineered,
then both models train (Logistic Regression via TensorFlow.js, Decision Tree from scratch) on the same
80/20 split before the dashboard is ready.

## Structure

- public/data/titanic.csv — 891 synthetic passengers with realistic historical survival patterns
  (sex, class, age, family size all genuinely predictive, plus unexplained variance) and some missing
  Age/Fare/Embarked values, so imputation is exercised for real
- src/utils/featureEngineering.js — median/mode imputation (computed from valid values only), Sex/
  Embarked encoding, FamilySize, IsAlone
- src/ml/preprocessing.js — 80/20 split (seeded, reproducible) + min-max normalization stats
- src/ml/logisticRegression.js — TensorFlow.js: single dense unit + sigmoid, binary cross-entropy
- src/ml/decisionTree.js — from-scratch CART classifier (Gini impurity, configurable max depth,
  feature importance from total impurity reduction)
- src/ml/modelTraining.js — trains both models on the same split so they're directly comparable
- src/utils/metrics.js — accuracy, precision, recall, F1, confusion matrix, and ROC-AUC (exact
  Mann-Whitney rank-sum formula, no threshold sweep needed)
- src/utils/insights.js — dynamic, dataset-derived observations (worded as "observed", never as
  guaranteed real-world rules)
- src/pages/ — Dashboard, Predict Survival, Passenger Analysis, Model Performance
- src/components/ — Sidebar, Header, StatCard, ChartCard, PredictionForm, PredictionResult,
  PassengerTable, PassengerDetails, ConfusionMatrix, ModelMetrics, ReportButton
- src/utils/reportGenerator.js — builds the downloadable PDF (jsPDF + html2canvas)

Swap in your own data by replacing public/data/titanic.csv, keeping the same column names
(PassengerId, Survived, Pclass, Name, Sex, Age, SibSp, Parch, Fare, Embarked).

## Prediction

On the Predict Survival page, pick a model (Logistic Regression or Decision Tree), fill in a passenger
profile, and click Predict Survival. Family Size and Is Alone are computed automatically. The result
shows a probability and a "Likely Survived / Likely Not Survived" call at the 50% threshold — always
framed as a model prediction based on historical data, never a certainty.

## Report download

"Download Report" generates titanic_survival_prediction_report.pdf with the dataset summary, both
models' metrics and the selected model's confusion matrix, the current prediction (if any), dynamic
insights, and a chart image. Blocks with "Please load the Titanic dataset first" / "Please train the
model first" if run too early.
