/** Standard binary classification metrics from actual labels + predicted probabilities. */
export function computeClassificationMetrics(actual, probabilities, threshold = 0.5) {
  const n = actual.length
  let tp = 0, tn = 0, fp = 0, fn = 0

  for (let i = 0; i < n; i++) {
    const predicted = probabilities[i] >= threshold ? 1 : 0
    if (predicted === 1 && actual[i] === 1) tp += 1
    else if (predicted === 0 && actual[i] === 0) tn += 1
    else if (predicted === 1 && actual[i] === 0) fp += 1
    else fn += 1
  }

  const accuracy = (tp + tn) / n
  const precision = tp + fp > 0 ? tp / (tp + fp) : 0
  const recall = tp + fn > 0 ? tp / (tp + fn) : 0
  const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0
  const rocAuc = computeRocAuc(actual, probabilities)

  return {
    accuracy, precision, recall, f1, rocAuc,
    confusionMatrix: { tp, tn, fp, fn },
    threshold,
    testSamples: n,
  }
}

/** ROC-AUC via the Mann-Whitney U / rank-sum formula (exact, no threshold sweep needed). */
function computeRocAuc(actual, probabilities) {
  const n = actual.length
  const positives = actual.filter((a) => a === 1).length
  const negatives = n - positives
  if (positives === 0 || negatives === 0) return 0.5

  const indexed = probabilities.map((p, i) => ({ p, label: actual[i] }))
  indexed.sort((a, b) => a.p - b.p)

  // Assign average rank to tied probability values.
  const ranks = new Array(n)
  let i = 0
  while (i < n) {
    let j = i
    while (j + 1 < n && indexed[j + 1].p === indexed[i].p) j += 1
    const avgRank = (i + j) / 2 + 1 // 1-indexed
    for (let k = i; k <= j; k++) ranks[k] = avgRank
    i = j + 1
  }

  let rankSumPositive = 0
  indexed.forEach((item, idx) => {
    if (item.label === 1) rankSumPositive += ranks[idx]
  })

  const auc = (rankSumPositive - (positives * (positives + 1)) / 2) / (positives * negatives)
  return auc
}
