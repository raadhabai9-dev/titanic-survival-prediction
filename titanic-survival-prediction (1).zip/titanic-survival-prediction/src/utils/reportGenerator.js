import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

const APP_NAME = 'Titanic Survival Prediction Report'

/**
 * Builds and downloads a PDF Titanic analysis report.
 * chartElement is an optional DOM node captured as an image and embedded
 * in the PDF. If capture fails, the report still generates without it.
 */
export async function generateTitanicReportPdf({
  summary, trainingResult, modelKey, prediction, insights, chartElement,
}) {
  if (!summary) {
    throw new Error('Please load the Titanic dataset first.')
  }
  if (!trainingResult) {
    throw new Error('Please train the model first.')
  }

  const model = trainingResult.models[modelKey]

  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()
  const margin = 48
  let y = margin

  const ensureSpace = (needed) => {
    if (y + needed > pageHeight - margin) {
      doc.addPage()
      y = margin
    }
  }

  const line = (text, size = 11, weight = 'normal', gap = 16) => {
    ensureSpace(gap)
    doc.setFont('helvetica', weight)
    doc.setFontSize(size)
    doc.text(text, margin, y)
    y += gap
  }

  // Cover
  doc.setFillColor(19, 32, 48)
  doc.rect(0, 0, pageWidth, 90, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(17)
  doc.text(APP_NAME, margin, 32)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.text(`Report generated: ${new Date().toLocaleString()}`, margin, 50)
  doc.text(`Dataset: titanic.csv  |  Model: ${model.label}  |  Split: ${trainingResult.trainingSamples}/${trainingResult.testingSamples} (train/test)`, margin, 66)
  doc.setTextColor(19, 32, 48)
  y = 118

  // Dataset summary
  line('Dataset Summary', 13, 'bold', 20)
  line(`Total Passengers: ${summary.totalPassengers}`)
  line(`Survivors: ${summary.survivedCount}`)
  line(`Non-Survivors: ${summary.notSurvivedCount}`)
  line(`Survival Rate: ${summary.survivalRate.toFixed(1)}%`)
  line(`Average Age: ${summary.averageAge.toFixed(1)}`)
  line(`Average Fare: £${summary.averageFare.toFixed(2)}`)
  y += 8

  // Model performance
  line('Model Performance', 13, 'bold', 20)
  Object.values(trainingResult.models).forEach((m) => {
    line(`${m.label}: Accuracy ${(m.metrics.accuracy * 100).toFixed(1)}%, Precision ${(m.metrics.precision * 100).toFixed(1)}%, Recall ${(m.metrics.recall * 100).toFixed(1)}%, F1 ${(m.metrics.f1 * 100).toFixed(1)}%, ROC-AUC ${m.metrics.rocAuc.toFixed(3)}`, 10)
  })
  y += 8

  // Confusion matrix for selected model
  line(`Confusion Matrix (${model.label})`, 12, 'bold', 16)
  const cm = model.metrics.confusionMatrix
  line(`True Positive: ${cm.tp}   True Negative: ${cm.tn}   False Positive: ${cm.fp}   False Negative: ${cm.fn}`, 10)
  y += 8

  // Current prediction
  line('Current Prediction', 13, 'bold', 20)
  if (prediction) {
    line(`Model Used: ${prediction.modelLabel}`)
    line(`Passenger Class: ${prediction.input.Pclass}, Sex: ${prediction.input.Sex}, Age: ${prediction.input.Age}, Fare: £${prediction.input.Fare}`)
    line(`Family Size: ${prediction.input.FamilySize}, Is Alone: ${prediction.input.IsAlone ? 'Yes' : 'No'}, Embarked: ${prediction.input.Embarked}`)
    line(`Survival Probability: ${(prediction.probability * 100).toFixed(1)}%`)
    line(`Predicted Status: ${prediction.survived ? 'Likely Survived' : 'Likely Not Survived'}`)
  } else {
    line('No individual prediction was generated.')
  }
  y += 8

  // Insights
  if (insights && insights.length) {
    line('Insights', 13, 'bold', 20)
    insights.forEach((text) => {
      const wrapped = doc.splitTextToSize(`• ${text}`, pageWidth - margin * 2)
      ensureSpace(wrapped.length * 14 + 4)
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(10)
      doc.text(wrapped, margin, y)
      y += wrapped.length * 14 + 4
    })
    y += 8
  }

  // Chart (best effort)
  if (chartElement) {
    try {
      const canvas = await html2canvas(chartElement, { backgroundColor: '#ffffff', scale: 2 })
      const imgData = canvas.toDataURL('image/png')
      const imgWidth = pageWidth - margin * 2
      const imgHeight = (canvas.height / canvas.width) * imgWidth

      ensureSpace(imgHeight + 24)
      line('Visualization', 13, 'bold', 20)
      doc.addImage(imgData, 'PNG', margin, y, imgWidth, imgHeight)
      y += imgHeight + 10
    } catch (err) {
      line('Chart could not be rendered for this report.', 10, 'italic')
    }
  }

  doc.save('titanic_survival_prediction_report.pdf')
}
