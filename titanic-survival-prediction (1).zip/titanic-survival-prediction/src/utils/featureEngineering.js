import { median } from '../services/dataset'

export const FEATURE_COLUMNS = [
  'Pclass', 'Sex_encoded', 'Age', 'Fare', 'SibSp', 'Parch',
  'FamilySize', 'IsAlone', 'Embarked_C', 'Embarked_Q', 'Embarked_S',
]

/** Computes median/mode imputation values from valid (non-missing) records only. */
export function computeImputationStats(rows) {
  const validAges = rows.filter((r) => typeof r.Age === 'number' && !Number.isNaN(r.Age)).map((r) => r.Age)
  const validFares = rows.filter((r) => typeof r.Fare === 'number' && !Number.isNaN(r.Fare)).map((r) => r.Fare)
  const embarkedCounts = {}
  rows.forEach((r) => {
    if (r.Embarked === 'S' || r.Embarked === 'C' || r.Embarked === 'Q') {
      embarkedCounts[r.Embarked] = (embarkedCounts[r.Embarked] || 0) + 1
    }
  })
  const modeEmbarked = Object.entries(embarkedCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'S'

  return {
    medianAge: validAges.length ? median(validAges) : 28,
    medianFare: validFares.length ? median(validFares) : 14,
    modeEmbarked,
  }
}

/** Cleans one passenger record: imputes missing values, encodes categories, adds engineered features. */
export function engineerPassenger(row, imputation) {
  const age = typeof row.Age === 'number' && !Number.isNaN(row.Age) ? row.Age : imputation.medianAge
  const fare = typeof row.Fare === 'number' && !Number.isNaN(row.Fare) ? row.Fare : imputation.medianFare
  const embarked = (row.Embarked === 'S' || row.Embarked === 'C' || row.Embarked === 'Q') ? row.Embarked : imputation.modeEmbarked

  const sibsp = row.SibSp ?? 0
  const parch = row.Parch ?? 0
  const familySize = sibsp + parch + 1
  const isAlone = familySize === 1 ? 1 : 0

  return {
    PassengerId: row.PassengerId,
    Name: row.Name,
    Survived: row.Survived,
    Pclass: row.Pclass,
    Sex: row.Sex,
    Sex_encoded: row.Sex === 'female' ? 1 : 0,
    Age: age,
    Fare: fare,
    SibSp: sibsp,
    Parch: parch,
    FamilySize: familySize,
    IsAlone: isAlone,
    Embarked: embarked,
    Embarked_C: embarked === 'C' ? 1 : 0,
    Embarked_Q: embarked === 'Q' ? 1 : 0,
    Embarked_S: embarked === 'S' ? 1 : 0,
  }
}

export function engineerDataset(rows) {
  const imputation = computeImputationStats(rows)
  const passengers = rows.map((r) => engineerPassenger(r, imputation))
  return { passengers, imputation }
}

export function featureVector(passenger) {
  return FEATURE_COLUMNS.map((col) => passenger[col])
}

/** Builds a full engineered passenger record from a prediction form's raw input. */
export function engineerFormInput(input, imputation) {
  return engineerPassenger({
    PassengerId: 'new',
    Survived: null,
    Pclass: input.Pclass,
    Name: '',
    Sex: input.Sex,
    Age: input.Age,
    SibSp: input.SibSp,
    Parch: input.Parch,
    Fare: input.Fare,
    Embarked: input.Embarked,
  }, imputation)
}
