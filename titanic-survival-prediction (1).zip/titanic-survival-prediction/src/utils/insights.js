const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

function survivalRateBy(passengers, keyFn) {
  const groups = {}
  passengers.forEach((p) => {
    const key = keyFn(p)
    if (!groups[key]) groups[key] = { total: 0, survived: 0 }
    groups[key].total += 1
    if (p.Survived === 1) groups[key].survived += 1
  })
  return Object.entries(groups).map(([key, v]) => ({ key, rate: (v.survived / v.total) * 100, count: v.total }))
}

/** Generates dynamic, dataset-derived observations — never hardcoded claims. */
export function generateDatasetInsights(passengers) {
  const insights = []

  const byGender = survivalRateBy(passengers, (p) => p.Sex)
  const female = byGender.find((g) => g.key === 'female')
  const male = byGender.find((g) => g.key === 'male')
  if (female && male) {
    const higher = female.rate >= male.rate ? 'Female' : 'Male'
    insights.push(`${higher} passengers have a higher observed survival rate in this dataset (female: ${female.rate.toFixed(1)}%, male: ${male.rate.toFixed(1)}%).`)
  }

  const byClass = survivalRateBy(passengers, (p) => p.Pclass).sort((a, b) => a.key - b.key)
  const bestClass = [...byClass].sort((a, b) => b.rate - a.rate)[0]
  if (bestClass) {
    insights.push(`Class ${bestClass.key} passengers have the highest observed survival rate (${bestClass.rate.toFixed(1)}%).`)
  }
  const largestClass = [...byClass].sort((a, b) => b.count - a.count)[0]
  if (largestClass) {
    insights.push(`Class ${largestClass.key} represents the largest passenger group (${largestClass.count} passengers).`)
  }

  const byFamily = survivalRateBy(passengers, (p) => (p.IsAlone ? 'Alone' : 'With Family'))
  const alone = byFamily.find((g) => g.key === 'Alone')
  const withFamily = byFamily.find((g) => g.key === 'With Family')
  if (alone && withFamily) {
    const higher = withFamily.rate >= alone.rate ? 'traveling with family' : 'traveling alone'
    insights.push(`Passengers ${higher} show a higher observed survival rate in this dataset.`)
  }

  return insights
}

/** Adds a model-comparison insight once both models have been trained. */
export function generateModelInsight(models) {
  const entries = Object.values(models)
  if (entries.length < 2) return null
  const best = [...entries].sort((a, b) => b.metrics.f1 - a.metrics.f1)[0]
  return `The model achieved the highest F1 score using ${best.label} (${(best.metrics.f1 * 100).toFixed(1)}%).`
}
