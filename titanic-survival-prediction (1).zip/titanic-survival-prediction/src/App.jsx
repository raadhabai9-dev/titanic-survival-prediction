import React, { useEffect, useState } from 'react'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Dashboard from './pages/Dashboard'
import PredictSurvival from './pages/PredictSurvival'
import PassengerAnalysis from './pages/PassengerAnalysis'
import ModelPerformance from './pages/ModelPerformance'
import { loadDataset } from './services/dataset'
import { engineerDataset } from './utils/featureEngineering'
import { trainModels } from './ml/modelTraining'

const STAGE_LABEL = {
  'loading-data': 'Preparing dataset…',
  cleaning: 'Cleaning passenger records…',
  features: 'Creating features…',
  training: 'Training model…',
  evaluating: 'Evaluating model…',
}

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const [passengers, setPassengers] = useState(null) // engineered, full dataset (with actual outcomes)
  const [trainingResult, setTrainingResult] = useState(null)
  const [stage, setStage] = useState('loading-data')
  const [error, setError] = useState(null)
  const [modelKey, setModelKey] = useState('logistic-regression')
  const [epochProgress, setEpochProgress] = useState({ epoch: 0, total: 60 })

  useEffect(() => {
    let cancelled = false
    async function run() {
      try {
        const rawRows = await loadDataset()
        if (cancelled) return
        setStage('cleaning')

        await new Promise((r) => setTimeout(r, 150))
        if (cancelled) return
        setStage('features')

        const { passengers: engineered } = engineerDataset(rawRows)
        if (cancelled) return
        setPassengers(engineered)

        await new Promise((r) => setTimeout(r, 120))
        if (cancelled) return
        setStage('training')

        const result = await trainModels(rawRows, {
          maxDepth: 5,
          epochs: 60,
          onEpoch: (epoch, total) => { if (!cancelled) setEpochProgress({ epoch, total }) },
        })
        if (cancelled) return
        setStage('evaluating')

        await new Promise((r) => setTimeout(r, 120))
        if (cancelled) return
        setTrainingResult(result)
        setStage('ready')
      } catch (err) {
        if (!cancelled) {
          setError(err.message || 'Something went wrong loading the app.')
          setStage('error')
        }
      }
    }
    run()
    return () => { cancelled = true }
  }, [])

  const status = stage === 'ready' ? 'ready' : stage === 'error' ? 'error' : 'loading'
  const modelLabel = trainingResult ? trainingResult.models[modelKey].label : (modelKey === 'logistic-regression' ? 'Logistic Regression' : 'Decision Tree')

  if (stage !== 'ready' && stage !== 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-paper px-6">
        <div className="text-center max-w-sm">
          <p className="font-display text-2xl text-ink mb-2">Titanic Survival Prediction</p>
          <p className="text-sm text-ink/50 mb-6">{STAGE_LABEL[stage]}</p>
          <div className="w-full h-1.5 bg-black/10 rounded-full overflow-hidden mb-2">
            <div
              className="h-full bg-navy2 transition-all duration-150"
              style={{ width: stage === 'training' ? `${(epochProgress.epoch / epochProgress.total) * 100}%` : '40%' }}
            />
          </div>
          {stage === 'training' && <p className="text-xs text-ink/40">Epoch {epochProgress.epoch} / {epochProgress.total}</p>}
        </div>
      </div>
    )
  }

  if (stage === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-paper px-6">
        <div className="text-center max-w-sm bg-white border border-black/5 rounded-lg p-6">
          <p className="font-display text-xl text-ink mb-2">Couldn't start the app</p>
          <p className="text-sm text-ink/60">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen md:flex">
      <Sidebar activePage={page} onNavigate={setPage} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 min-w-0">
        <Header activePage={page} onMenuClick={() => setSidebarOpen(true)} status={status} model={modelLabel} />
        <main className="p-4 md:p-8 min-w-0">
          {page === 'dashboard' && <Dashboard passengers={passengers} />}
          {page === 'predict' && (
            <PredictSurvival
              passengers={passengers}
              trainingResult={trainingResult}
              modelKey={modelKey}
              onModelChange={setModelKey}
              status={status}
            />
          )}
          {page === 'analysis' && <PassengerAnalysis passengers={passengers} />}
          {page === 'performance' && (
            <ModelPerformance trainingResult={trainingResult} modelKey={modelKey} onModelChange={setModelKey} />
          )}
        </main>
      </div>
    </div>
  )
}
