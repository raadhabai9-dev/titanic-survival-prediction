import React, { useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { computeSummary } from '../services/dataset'
import { generateDatasetInsights } from '../utils/insights'

function histogram(values, buckets = 6) {
  const min = Math.min(...values)
  const max = Math.max(...values)
  const width = (max - min) / buckets || 1
  const bins = Array.from({ length: buckets }, (_, i) => ({
    range: `${Math.round(min + i * width)}-${Math.round(min + (i + 1) * width)}`,
    count: 0,
  }))
  values.forEach((v) => {
    let idx = Math.floor((v - min) / width)
    if (idx >= buckets) idx = buckets - 1
    if (idx < 0) idx = 0
    bins[idx].count += 1
  })
  return bins
}

export default function Dashboard({ passengers }) {
  const summary = computeSummary(passengers)
  const insights = useMemo(() => generateDatasetInsights(passengers), [passengers])

  const survivalDist = [
    { name: 'Survived', value: summary.survivedCount },
    { name: 'Not Survived', value: summary.notSurvivedCount },
  ]

  const byGender = useMemo(() => {
    const groups = { male: { total: 0, survived: 0 }, female: { total: 0, survived: 0 } }
    passengers.forEach((p) => { groups[p.Sex].total += 1; if (p.Survived) groups[p.Sex].survived += 1 })
    return Object.entries(groups).map(([sex, v]) => ({ sex, rate: Number(((v.survived / v.total) * 100).toFixed(1)) }))
  }, [passengers])

  const byClass = useMemo(() => {
    const groups = {}
    passengers.forEach((p) => {
      if (!groups[p.Pclass]) groups[p.Pclass] = { total: 0, survived: 0 }
      groups[p.Pclass].total += 1
      if (p.Survived) groups[p.Pclass].survived += 1
    })
    return Object.entries(groups).sort((a, b) => a[0] - b[0]).map(([pclass, v]) => ({ pclass: `Class ${pclass}`, rate: Number(((v.survived / v.total) * 100).toFixed(1)) }))
  }, [passengers])

  const ageDist = useMemo(() => histogram(passengers.map((p) => p.Age)), [passengers])
  const fareDist = useMemo(() => histogram(passengers.map((p) => p.Fare)), [passengers])

  const COLORS = ['#2C5B7A', '#8E3B46']

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard label="Total Passengers" value={summary.totalPassengers} />
        <StatCard label="Survived Passengers" value={summary.survivedCount} />
        <StatCard label="Non-Survived Passengers" value={summary.notSurvivedCount} />
        <StatCard label="Overall Survival Rate" value={`${summary.survivalRate.toFixed(1)}%`} />
        <StatCard label="Average Passenger Age" value={summary.averageAge.toFixed(1)} />
        <StatCard label="Average Fare" value={`£${summary.averageFare.toFixed(2)}`} />
      </div>

      {insights.length > 0 && (
        <div className="bg-white rounded-lg border border-black/5 px-5 py-3 space-y-1">
          {insights.slice(0, 2).map((text, i) => (
            <p key={i} className="text-sm text-ink/70">{text}</p>
          ))}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Survival Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={survivalDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {survivalDist.map((d, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Survival Rate by Gender">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={byGender} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="sex" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="rate" fill="#2C5B7A" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Survival Rate by Passenger Class">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={byClass} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="pclass" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="rate" fill="#C08A3E" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Age Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ageDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 9 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#2C5B7A" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Fare Distribution" className="md:col-span-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={fareDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 9 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#8E3B46" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
