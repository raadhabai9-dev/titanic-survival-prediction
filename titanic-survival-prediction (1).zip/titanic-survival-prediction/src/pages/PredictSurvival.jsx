import React, { useRef, useState } from 'react'
import PredictionForm from '../components/PredictionForm'
import PredictionResult from '../components/PredictionResult'
import ReportButton from '../components/ReportButton'
import { engineerFormInput } from '../utils/featureEngineering'
import { computeSummary } from '../services/dataset'
import { generateDatasetInsights, generateModelInsight } from '../utils/insights'

export default function PredictSurvival({ passengers, trainingResult, modelKey, onModelChange, status }) {
  const [result, setResult] = useState(null)
  const resultRef = useRef(null)

  const ready = status === 'ready' && trainingResult

  const handleSubmit = (rawInput) => {
    if (!ready) return
    const model = trainingResult.models[modelKey]
    const engineered = engineerFormInput(rawInput, trainingResult.imputation)
    const probability = model.predictProbability(engineered)
    const survived = probability >= 0.5

    setResult({
      probability,
      survived,
      threshold: 0.5,
      modelLabel: model.label,
      input: engineered,
    })
  }

  const summary = computeSummary(passengers)
  const insights = [...generateDatasetInsights(passengers)]
  const modelInsight = trainingResult ? generateModelInsight(trainingResult.models) : null
  if (modelInsight) insights.push(modelInsight)

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-2 gap-6">
        <PredictionForm modelKey={modelKey} onModelChange={onModelChange} onSubmit={handleSubmit} disabled={!ready} />
        <PredictionResult result={result} innerRef={resultRef} />
      </div>

      {result && (
        <div className="flex justify-end">
          <ReportButton
            summary={summary}
            trainingResult={trainingResult}
            modelKey={modelKey}
            prediction={result}
            insights={insights}
            chartElement={resultRef.current}
          />
        </div>
      )}
    </div>
  )
}
