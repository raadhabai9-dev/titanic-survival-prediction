import React, { useMemo, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import PassengerTable from '../components/PassengerTable'
import PassengerDetails from '../components/PassengerDetails'
import { median } from '../services/dataset'

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

function ageGroup(age) {
  if (age <= 12) return 'Child'
  if (age <= 25) return 'Young Adult'
  if (age <= 59) return 'Adult'
  return 'Senior'
}

function survivalRateBy(passengers, keyFn, order) {
  const groups = {}
  passengers.forEach((p) => {
    const key = keyFn(p)
    if (!groups[key]) groups[key] = { total: 0, survived: 0 }
    groups[key].total += 1
    if (p.Survived) groups[key].survived += 1
  })
  const entries = Object.entries(groups).map(([key, v]) => ({ key, rate: Number(((v.survived / v.total) * 100).toFixed(1)), count: v.total }))
  if (order) return order.map((k) => entries.find((e) => e.key === k)).filter(Boolean)
  return entries
}

export default function PassengerAnalysis({ passengers }) {
  const [selected, setSelected] = useState(null)

  const survivors = passengers.filter((p) => p.Survived === 1)
  const nonSurvivors = passengers.filter((p) => p.Survived === 0)

  const avgFamilySize = avg(passengers.map((p) => p.FamilySize))
  const medianAge = median(passengers.map((p) => p.Age))
  const avgFareSurvivors = avg(survivors.map((p) => p.Fare))
  const avgFareNonSurvivors = avg(nonSurvivors.map((p) => p.Fare))

  const byGender = useMemo(() => survivalRateBy(passengers, (p) => p.Sex), [passengers])
  const byClass = useMemo(() => survivalRateBy(passengers, (p) => `Class ${p.Pclass}`, ['Class 1', 'Class 2', 'Class 3']), [passengers])
  const byAgeGroup = useMemo(() => survivalRateBy(passengers, (p) => ageGroup(p.Age), ['Child', 'Young Adult', 'Adult', 'Senior']), [passengers])
  const byEmbarked = useMemo(() => survivalRateBy(passengers, (p) => p.Embarked), [passengers])
  const byFamilySize = useMemo(() => {
    const bucket = (fs) => (fs === 1 ? 'Alone' : fs <= 4 ? 'Small (2-4)' : 'Large (5+)')
    return survivalRateBy(passengers, (p) => bucket(p.FamilySize), ['Alone', 'Small (2-4)', 'Large (5+)'])
  }, [passengers])

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Average Age" value={avg(passengers.map((p) => p.Age)).toFixed(1)} />
        <StatCard label="Median Age" value={medianAge.toFixed(1)} />
        <StatCard label="Average Fare" value={`£${avg(passengers.map((p) => p.Fare)).toFixed(2)}`} />
        <StatCard label="Average Family Size" value={avgFamilySize.toFixed(1)} />
        <StatCard label="Survival Rate" value={`${((survivors.length / passengers.length) * 100).toFixed(1)}%`} />
        <StatCard label="Avg Fare (Survivors)" value={`£${avgFareSurvivors.toFixed(2)}`} />
        <StatCard label="Avg Fare (Non-Survivors)" value={`£${avgFareNonSurvivors.toFixed(2)}`} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Survival by Gender">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={byGender} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="key" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="rate" fill="#2C5B7A" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Survival by Class">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={byClass} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="key" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="rate" fill="#C08A3E" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Survival by Age Group">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={byAgeGroup} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="key" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="rate" fill="#2C5B7A" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Survival by Embarkation Port">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={byEmbarked} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="key" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="rate" fill="#8E3B46" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Survival by Family Size" className="md:col-span-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={byFamilySize} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e7eaec" vertical={false} />
              <XAxis dataKey="key" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="rate" fill="#C08A3E" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 min-w-0">
          <PassengerTable passengers={passengers} onSelect={setSelected} selectedId={selected?.PassengerId} />
        </div>
        <PassengerDetails passenger={selected} />
      </div>
    </div>
  )
}
