import React from 'react'
import StatCard from './StatCard'

export default function ModelMetrics({ metrics, label }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
      <StatCard label="Model" value={label} />
      <StatCard label="Accuracy" value={`${(metrics.accuracy * 100).toFixed(1)}%`} />
      <StatCard label="Precision" value={`${(metrics.precision * 100).toFixed(1)}%`} />
      <StatCard label="Recall" value={`${(metrics.recall * 100).toFixed(1)}%`} />
      <StatCard label="F1 Score" value={`${(metrics.f1 * 100).toFixed(1)}%`} />
    </div>
  )
}
