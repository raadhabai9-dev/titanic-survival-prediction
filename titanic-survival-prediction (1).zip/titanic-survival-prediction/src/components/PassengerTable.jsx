import React, { useMemo, useState } from 'react'

const PAGE_SIZE = 10

const COLUMNS = [
  { key: 'PassengerId', label: 'ID' },
  { key: 'Age', label: 'Age' },
  { key: 'Sex', label: 'Sex' },
  { key: 'Pclass', label: 'Class' },
  { key: 'Fare', label: 'Fare' },
  { key: 'FamilySize', label: 'Family Size' },
  { key: 'Embarked', label: 'Embarked' },
  { key: 'Survived', label: 'Survived' },
]

export default function PassengerTable({ passengers, onSelect, selectedId }) {
  const [search, setSearch] = useState('')
  const [sexFilter, setSexFilter] = useState('all')
  const [classFilter, setClassFilter] = useState('all')
  const [survivedFilter, setSurvivedFilter] = useState('all')
  const [sortKey, setSortKey] = useState('PassengerId')
  const [sortDir, setSortDir] = useState('asc')
  const [page, setPage] = useState(1)

  const filtered = useMemo(() => {
    let result = passengers
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      result = result.filter((p) => String(p.PassengerId).includes(q) || (p.Name || '').toLowerCase().includes(q))
    }
    if (sexFilter !== 'all') result = result.filter((p) => p.Sex === sexFilter)
    if (classFilter !== 'all') result = result.filter((p) => p.Pclass === Number(classFilter))
    if (survivedFilter !== 'all') result = result.filter((p) => p.Survived === Number(survivedFilter))

    return [...result].sort((a, b) => {
      const av = a[sortKey]
      const bv = b[sortKey]
      const diff = typeof av === 'string' ? av.localeCompare(bv) : av - bv
      return sortDir === 'asc' ? diff : -diff
    })
  }, [passengers, search, sexFilter, classFilter, survivedFilter, sortKey, sortDir])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages)
  const pageRows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)

  const toggleSort = (key) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    else { setSortKey(key); setSortDir('asc') }
    setPage(1)
  }

  return (
    <div className="bg-white rounded-lg border border-black/5 p-5 min-w-0">
      <div className="flex flex-col sm:flex-row flex-wrap gap-3 mb-4">
        <input
          type="text"
          placeholder="Search by ID or name"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1) }}
          className="flex-1 border border-black/10 rounded-md px-3 py-2 text-sm min-w-0"
        />
        <select value={sexFilter} onChange={(e) => { setSexFilter(e.target.value); setPage(1) }} className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white">
          <option value="all">All Sexes</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
        <select value={classFilter} onChange={(e) => { setClassFilter(e.target.value); setPage(1) }} className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white">
          <option value="all">All Classes</option>
          <option value="1">1st Class</option>
          <option value="2">2nd Class</option>
          <option value="3">3rd Class</option>
        </select>
        <select value={survivedFilter} onChange={(e) => { setSurvivedFilter(e.target.value); setPage(1) }} className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white">
          <option value="all">All Outcomes</option>
          <option value="1">Survived</option>
          <option value="0">Not Survived</option>
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[620px]">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
              {COLUMNS.map((col) => (
                <th key={col.key} onClick={() => toggleSort(col.key)} className="py-2 pr-4 cursor-pointer select-none whitespace-nowrap">
                  {col.label}{sortKey === col.key ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ''}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((p) => (
              <tr
                key={p.PassengerId}
                onClick={() => onSelect(p)}
                className={`border-b border-black/5 last:border-0 cursor-pointer hover:bg-black/[0.02] ${selectedId === p.PassengerId ? 'bg-black/[0.03]' : ''}`}
              >
                <td className="py-2 pr-4">{p.PassengerId}</td>
                <td className="py-2 pr-4">{p.Age.toFixed(0)}</td>
                <td className="py-2 pr-4">{p.Sex}</td>
                <td className="py-2 pr-4">{p.Pclass}</td>
                <td className="py-2 pr-4">£{p.Fare.toFixed(2)}</td>
                <td className="py-2 pr-4">{p.FamilySize}</td>
                <td className="py-2 pr-4">{p.Embarked}</td>
                <td className="py-2 pr-4">
                  <span className={`px-2 py-0.5 rounded-full text-xs ${p.Survived ? 'bg-navy2/10 text-navy2' : 'bg-wine/10 text-wine'}`}>
                    {p.Survived ? 'Survived' : 'Not Survived'}
                  </span>
                </td>
              </tr>
            ))}
            {pageRows.length === 0 && (
              <tr><td colSpan={COLUMNS.length} className="py-6 text-center text-ink/40">No passengers match your filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-4 text-sm text-ink/50">
        <span>{filtered.length} passengers</span>
        <div className="flex items-center gap-2">
          <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={currentPage <= 1} className="px-3 py-1 rounded border border-black/10 disabled:opacity-40">Prev</button>
          <span>{currentPage} / {totalPages}</span>
          <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage >= totalPages} className="px-3 py-1 rounded border border-black/10 disabled:opacity-40">Next</button>
        </div>
      </div>
    </div>
  )
}
