import React from 'react'

export default function PassengerDetails({ passenger }) {
  if (!passenger) {
    return (
      <div className="bg-white rounded-lg border border-black/5 border-dashed p-6 text-center text-ink/40 text-sm">
        Select a passenger from the table to see their details.
      </div>
    )
  }

  const rows = [
    ['Passenger ID', passenger.PassengerId],
    ['Name', passenger.Name],
    ['Sex', passenger.Sex],
    ['Age', passenger.Age.toFixed(1)],
    ['Passenger Class', passenger.Pclass],
    ['Fare', `£${passenger.Fare.toFixed(2)}`],
    ['Siblings/Spouses', passenger.SibSp],
    ['Parents/Children', passenger.Parch],
    ['Family Size', passenger.FamilySize],
    ['Embarked', passenger.Embarked],
  ]

  return (
    <div className="bg-white rounded-lg border border-black/5 p-6">
      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Actual Status</p>
      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium mb-5 ${passenger.Survived ? 'bg-navy2 text-white' : 'bg-wine text-white'}`}>
        {passenger.Survived ? 'Survived' : 'Not Survived'}
      </span>

      <div className="space-y-2">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium text-right">{value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
