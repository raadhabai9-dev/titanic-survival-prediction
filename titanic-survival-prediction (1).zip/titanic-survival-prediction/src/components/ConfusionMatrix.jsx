import React from 'react'

export default function ConfusionMatrix({ matrix }) {
  const { tp, tn, fp, fn } = matrix
  return (
    <div className="bg-white rounded-lg border border-black/5 p-5">
      <h3 className="text-sm font-medium text-ink mb-4">Confusion Matrix</h3>
      <div className="grid grid-cols-[auto_1fr_1fr] gap-1 text-sm max-w-sm">
        <div />
        <div className="text-center text-xs text-ink/40 pb-1">Predicted No</div>
        <div className="text-center text-xs text-ink/40 pb-1">Predicted Yes</div>

        <div className="text-xs text-ink/40 flex items-center pr-2">Actual No</div>
        <div className="bg-navy2/10 text-navy2 rounded p-3 text-center font-medium">{tn}</div>
        <div className="bg-wine/10 text-wine rounded p-3 text-center font-medium">{fp}</div>

        <div className="text-xs text-ink/40 flex items-center pr-2">Actual Yes</div>
        <div className="bg-wine/10 text-wine rounded p-3 text-center font-medium">{fn}</div>
        <div className="bg-navy2/10 text-navy2 rounded p-3 text-center font-medium">{tp}</div>
      </div>
    </div>
  )
}
