import React, { useState } from 'react'

const DEFAULTS = {
  Pclass: 3,
  Sex: 'male',
  Age: 28,
  Fare: 14,
  SibSp: 0,
  Parch: 0,
  Embarked: 'S',
}

export default function PredictionForm({ modelKey, onModelChange, onSubmit, disabled }) {
  const [form, setForm] = useState(DEFAULTS)
  const familySize = form.SibSp + form.Parch + 1
  const isAlone = familySize === 1

  const handleChange = (field, value) => setForm((f) => ({ ...f, [field]: value }))

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit({ ...form, FamilySize: familySize, IsAlone: isAlone ? 1 : 0 })
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-black/5 p-6 space-y-5">
      <div>
        <label className="text-sm text-ink/70 block mb-1">Model</label>
        <select
          value={modelKey}
          onChange={(e) => onModelChange(e.target.value)}
          className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="logistic-regression">Logistic Regression</option>
          <option value="decision-tree">Decision Tree</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-sm text-ink/70 block mb-1">Passenger Class</label>
          <select
            value={form.Pclass}
            onChange={(e) => handleChange('Pclass', Number(e.target.value))}
            className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
          >
            <option value={1}>1st Class</option>
            <option value={2}>2nd Class</option>
            <option value={3}>3rd Class</option>
          </select>
        </div>
        <div>
          <label className="text-sm text-ink/70 block mb-1">Sex</label>
          <select
            value={form.Sex}
            onChange={(e) => handleChange('Sex', e.target.value)}
            className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
          >
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </div>
      </div>

      <div>
        <div className="flex justify-between text-sm mb-1">
          <label className="text-ink/70">Age</label>
          <span className="text-ink font-medium">{form.Age}</span>
        </div>
        <input
          type="range" min={0} max={80} step={1}
          value={form.Age}
          onChange={(e) => handleChange('Age', Number(e.target.value))}
          className="w-full accent-navy2"
        />
      </div>

      <div>
        <label className="text-sm text-ink/70 block mb-1">Fare (£)</label>
        <input
          type="number" min={0} max={600} step={1}
          value={form.Fare}
          onChange={(e) => handleChange('Fare', Number(e.target.value))}
          className="w-full border border-black/10 rounded-md px-3 py-2 text-sm"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-sm text-ink/70 block mb-1">Siblings/Spouses</label>
          <input
            type="number" min={0} max={8}
            value={form.SibSp}
            onChange={(e) => handleChange('SibSp', Number(e.target.value))}
            className="w-full border border-black/10 rounded-md px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="text-sm text-ink/70 block mb-1">Parents/Children</label>
          <input
            type="number" min={0} max={8}
            value={form.Parch}
            onChange={(e) => handleChange('Parch', Number(e.target.value))}
            className="w-full border border-black/10 rounded-md px-3 py-2 text-sm"
          />
        </div>
      </div>

      <div>
        <label className="text-sm text-ink/70 block mb-1">Embarked</label>
        <select
          value={form.Embarked}
          onChange={(e) => handleChange('Embarked', e.target.value)}
          className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="S">Southampton</option>
          <option value="C">Cherbourg</option>
          <option value="Q">Queenstown</option>
        </select>
      </div>

      <div className="bg-paper rounded-md px-3 py-2 text-xs text-ink/60 flex justify-between">
        <span>Family Size: <span className="text-ink font-medium">{familySize}</span></span>
        <span>Is Alone: <span className="text-ink font-medium">{isAlone ? 'Yes' : 'No'}</span></span>
      </div>

      <button
        type="submit"
        disabled={disabled}
        className="w-full bg-ink text-white rounded-md py-2.5 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-ink/90 transition-colors"
      >
        {disabled ? 'Training model…' : 'Predict Survival'}
      </button>
    </form>
  )
}
