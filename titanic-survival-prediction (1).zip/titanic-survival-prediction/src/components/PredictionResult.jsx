import React from 'react'

export default function PredictionResult({ result, innerRef }) {
  if (!result) {
    return (
      <div className="h-full min-h-[240px] bg-white rounded-lg border border-black/5 border-dashed flex items-center justify-center text-ink/40 text-sm p-6 text-center">
        Fill in the form and click Predict Survival to see a result here.
      </div>
    )
  }

  const { probability, survived, input, threshold, modelLabel } = result
  const pct = (probability * 100).toFixed(0)

  return (
    <div ref={innerRef} className="bg-white rounded-lg border border-black/5 p-6">
      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Prediction Result</p>
      <div className="flex items-center gap-3 mb-2">
        <span className={`font-display text-3xl ${survived ? 'text-navy2' : 'text-wine'}`}>
          {survived ? 'Likely Survived' : 'Likely Not Survived'}
        </span>
      </div>
      <p className="text-xs text-ink/40 mb-5">Model prediction based on historical Titanic data ({modelLabel}).</p>

      <div className="mb-2 flex justify-between text-sm">
        <span className="text-ink/60">Survival Probability</span>
        <span className="text-ink font-medium">{pct}%</span>
      </div>
      <div className="w-full h-2.5 bg-black/5 rounded-full overflow-hidden mb-1">
        <div
          className={`h-full rounded-full transition-all duration-500 ${survived ? 'bg-navy2' : 'bg-wine'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <p className="text-xs text-ink/40 mb-6">Classification threshold: {(threshold * 100).toFixed(0)}%</p>

      <div className="space-y-2">
        {[
          ['Passenger Class', input.Pclass],
          ['Sex', input.Sex],
          ['Age', input.Age],
          ['Fare', `£${input.Fare}`],
          ['Family Size', input.FamilySize],
          ['Is Alone', input.IsAlone ? 'Yes' : 'No'],
          ['Embarked', input.Embarked],
        ].map(([label, value]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium">{value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
