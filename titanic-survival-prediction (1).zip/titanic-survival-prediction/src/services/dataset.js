import Papa from 'papaparse'

const REQUIRED_COLUMNS = ['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']

/** Loads and parses the Titanic dataset shipped with the app. */
export async function loadDataset() {
  let response
  try {
    response = await fetch('/data/titanic.csv')
  } catch (err) {
    throw new Error('Could not reach the dataset file. Check your connection and reload.')
  }

  if (!response.ok) {
    throw new Error(`Please load the Titanic dataset first. (status ${response.status})`)
  }

  const csvText = await response.text()

  const parsed = Papa.parse(csvText, {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
  })

  if (parsed.errors && parsed.errors.length > 0) {
    throw new Error('The dataset CSV is malformed and could not be parsed.')
  }

  const fields = parsed.meta.fields || []
  const missingColumns = REQUIRED_COLUMNS.filter((c) => !fields.includes(c))
  if (missingColumns.length > 0) {
    throw new Error(`Dataset is missing required columns: ${missingColumns.join(', ')}.`)
  }

  const seen = new Set()
  const rows = parsed.data.filter((row) => {
    if (typeof row.PassengerId === 'undefined' || row.PassengerId === null) return false
    if (row.Survived !== 0 && row.Survived !== 1) return false
    if (![1, 2, 3].includes(row.Pclass)) return false
    if (row.Sex !== 'male' && row.Sex !== 'female') return false

    if (seen.has(row.PassengerId)) return false // drop duplicate records
    seen.add(row.PassengerId)
    return true
  })

  if (rows.length < 100) {
    throw new Error('Dataset has too few valid passenger records to train a reliable model.')
  }

  return rows
}

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

export function computeSummary(rows) {
  const survivors = rows.filter((r) => r.Survived === 1)
  const validAges = rows.filter((r) => typeof r.Age === 'number' && !Number.isNaN(r.Age)).map((r) => r.Age)
  const validFares = rows.filter((r) => typeof r.Fare === 'number' && !Number.isNaN(r.Fare)).map((r) => r.Fare)

  return {
    totalPassengers: rows.length,
    survivedCount: survivors.length,
    notSurvivedCount: rows.length - survivors.length,
    survivalRate: (survivors.length / rows.length) * 100,
    averageAge: validAges.length ? avg(validAges) : 0,
    averageFare: validFares.length ? avg(validFares) : 0,
  }
}

export function median(values) {
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2
}
