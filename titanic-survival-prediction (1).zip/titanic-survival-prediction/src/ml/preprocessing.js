import { FEATURE_COLUMNS, featureVector } from '../utils/featureEngineering'

/** Shuffles and splits passengers into 80% train / 20% test, deterministically. */
export function trainTestSplit(passengers, testRatio = 0.2, seed = 42) {
  const shuffled = seededShuffle(passengers, seed)
  const testSize = Math.max(1, Math.round(shuffled.length * testRatio))
  const testSet = shuffled.slice(0, testSize)
  const trainSet = shuffled.slice(testSize)
  return { trainSet, testSet }
}

function seededShuffle(array, seed) {
  const result = [...array]
  let s = seed
  const random = () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1))
    ;[result[i], result[j]] = [result[j], result[i]]
  }
  return result
}

/** Computes per-feature min/max from training passengers only. */
export function computeFeatureStats(passengers) {
  const stats = {}
  FEATURE_COLUMNS.forEach((col) => {
    const values = passengers.map((p) => p[col])
    stats[col] = { min: Math.min(...values), max: Math.max(...values) }
  })
  return stats
}

export function normalizeValue(value, min, max) {
  if (max === min) return 0
  return (value - min) / (max - min)
}

export function normalizedFeatureVector(passenger, stats) {
  return FEATURE_COLUMNS.map((col) => normalizeValue(passenger[col], stats[col].min, stats[col].max))
}

export { featureVector }
