import { engineerDataset } from '../utils/featureEngineering'
import { trainTestSplit, computeFeatureStats } from './preprocessing'
import { trainLogisticRegression } from './logisticRegression'
import { trainDecisionTree } from './decisionTree'
import { computeClassificationMetrics } from '../utils/metrics'

/**
 * Full training pipeline: engineer features, split 80/20, train both
 * Logistic Regression and Decision Tree, and evaluate each on the same
 * held-out test set so they're directly comparable.
 */
export async function trainModels(rawRows, { maxDepth = 5, epochs = 60, onEpoch } = {}) {
  const { passengers, imputation } = engineerDataset(rawRows)
  const { trainSet, testSet } = trainTestSplit(passengers, 0.2, 42)
  const featureStats = computeFeatureStats(trainSet)

  const logistic = await trainLogisticRegression(trainSet, featureStats, { epochs, onEpoch })
  const tree = trainDecisionTree(trainSet, { maxDepth })

  const actual = testSet.map((p) => p.Survived)

  const logisticProbs = testSet.map((p) => logistic.predictProbability(p))
  const logisticMetrics = computeClassificationMetrics(actual, logisticProbs)

  const treeProbs = testSet.map((p) => tree.predictProbability(p))
  const treeMetrics = computeClassificationMetrics(actual, treeProbs)

  return {
    imputation,
    featureStats,
    trainSet,
    testSet,
    trainingSamples: trainSet.length,
    testingSamples: testSet.length,
    models: {
      'logistic-regression': { ...logistic, metrics: logisticMetrics, label: 'Logistic Regression' },
      'decision-tree': { ...tree, metrics: treeMetrics, label: 'Decision Tree' },
    },
  }
}
