/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#132030',
        slate: { 925: '#0F1927' },
        navy2: '#2C5B7A',
        brass: '#C08A3E',
        wine: '#8E3B46',
        paper: '#F6F7F7',
      },
      fontFamily: {
        sans: ['"Source Sans 3"', 'system-ui', 'sans-serif'],
        display: ['"Playfair Display"', 'serif'],
      },
    },
  },
  plugins: [],
}
